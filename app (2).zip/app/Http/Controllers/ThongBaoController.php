<?php

namespace App\Http\Controllers;

use App\Models\ThongBao;
use App\Models\NguoiDung;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ThongBaoController extends Controller
{
    /**
     * =========================
     * DANH SÁCH THÔNG BÁO
     * =========================
     */
    public function index()
    {
        // Lấy user từ session (đã lưu object khi login)
        $user = session('user');

        if (!$user) {
            return redirect()->route('login')->with('error', 'Bạn cần đăng nhập để xem thông báo.');
        }

        // Lấy toàn bộ thông báo để hiển thị trong trang
        $thongBaos = ThongBao::where('ma_nguoi_nhan', $user->ma_nguoi_dung)
            ->orderByDesc('thoi_gian_tao')
            ->get();

        // Đánh dấu tất cả thông báo chưa đọc thành đã đọc
        ThongBao::where('ma_nguoi_nhan', $user->ma_nguoi_dung)
            ->where('da_doc', 0)
            ->update(['da_doc' => 1]);

        // Dữ liệu cho header
        $soThongBaoChuaDoc = ThongBao::where('ma_nguoi_nhan', $user->ma_nguoi_dung)
            ->where('da_doc', 0)
            ->count();

        $thongBaosHeader = ThongBao::where('ma_nguoi_nhan', $user->ma_nguoi_dung)
            ->orderByDesc('thoi_gian_tao')
            ->limit(5)
            ->get();

        return view('thongbao.index', [
            'user' => $user,
            'thongBaos' => $thongBaos,              // danh sách đầy đủ
            'soThongBaoChuaDoc' => $soThongBaoChuaDoc, // số lượng cho header
            'thongBaosHeader' => $thongBaosHeader,     // 5 thông báo mới nhất cho header
        ]);
    }

    /**
     * =========================
     * ĐÁNH DẤU ĐÃ ĐỌC
     * =========================
     */
    public function daDoc($id)
    {
        $thongBao = ThongBao::findOrFail($id);
        $thongBao->da_doc = 1;
        $thongBao->save();

        return back();
    }
}