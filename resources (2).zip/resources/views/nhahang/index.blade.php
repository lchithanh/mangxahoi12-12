@extends('layout.header')

@section('title', 'Danh sách nhà hàng')

@section('maincontent')
<div class="container py-5">
    <h2 class="mb-4 text-center">Danh sách nhà hàng</h2>
    {{-- Nếu đã đăng nhập và là chủ quán thì hiện nút tạo --}}
    @if($user && $user->vai_tro === 'chu_quan')
        <div class="mb-3 text-end">
            <a href="{{ route('nhahang.create') }}" class="btn btn-primary">+ Tạo nhà hàng mới</a>
        </div>
    @endif


    {{-- Include partial hiển thị card --}}
    @include('nhahang.card', ['nhaHangs' => $nhaHangs])
</div>
@endsection
