@extends('layout.header')

@section('title', 'Thông báo')

@section('maincontent')
<div class="card shadow-sm">
    {{-- Tiêu đề của card --}}
    <div class="card-header fw-bold">Tất cả thông báo</div>

    {{-- Danh sách thông báo --}}
    <ul class="list-group list-group-flush">
        @forelse($thongBaos as $tb)
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div>
                    {{-- Nội dung thông báo --}}
                    <div>{{ $tb->noi_dung }}</div>

                    {{-- Thời gian tạo thông báo, hiển thị dạng "2 giờ trước" --}}
                    <small class="text-muted">
                        {{ $tb->thoi_gian_tao->diffForHumans() }}
                    </small>
                </div>

                {{-- Nút đánh dấu đã đọc (nếu chưa đọc) --}}
                @if(!$tb->da_doc)
                    <form action="{{ route('thongbao.dadoc', $tb->ma_thong_bao) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-outline-secondary">
                            Đánh dấu đã đọc
                        </button>
                    </form>
                @endif
            </li>
        @empty
            {{-- Trường hợp không có thông báo nào --}}
            <li class="list-group-item text-center text-muted">
                Không có thông báo
            </li>
        @endforelse
    </ul>
</div>
@endsection