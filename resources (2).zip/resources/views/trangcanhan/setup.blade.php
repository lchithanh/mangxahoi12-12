@extends('layout.header')

@section('title', 'Chỉnh sửa hồ sơ')

@section('maincontent')
<div class="container py-4">
    <h3>Chỉnh sửa hồ sơ</h3>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form action="{{ route('trangcanhan.saveSetup') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="mb-3">
            <label for="ho_ten" class="form-label">Họ tên</label>
            <input type="text" name="ho_ten" class="form-control" value="{{ old('ho_ten', $user->ho_ten) }}">
            @error('ho_ten') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" class="form-control" value="{{ old('email', $user->email) }}">
            @error('email') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="mb-3">
            <label for="mo_ta" class="form-label">Mô tả</label>
            <textarea name="mo_ta" class="form-control">{{ old('mo_ta', $user->mo_ta) }}</textarea>
            @error('mo_ta') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <div class="mb-3">
            <label for="anh_dai_dien" class="form-label">Ảnh đại diện</label>
            <input type="file" name="anh_dai_dien" class="form-control">
            @if($user->anh_dai_dien)
                <img src="{{ asset($user->anh_dai_dien) }}" class="mt-2" style="width:100px; height:100px; object-fit:cover;">
            @endif
            @error('anh_dai_dien') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
    </form>
</div>
@endsection
